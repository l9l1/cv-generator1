# CV Platform (Next.js + Prisma + Postgres)

منصّة جاهزة لإنشاء سِيَر ذاتية احترافية بالعربية/الإنجليزية (RTL)، مع تصدير PDF.

## التقنيات
- Next.js (App Router)
- Prisma + PostgreSQL
- TailwindCSS
- @react-pdf/renderer لتوليد PDF
- Docker Compose لقاعدة البيانات

## التشغيل محليًا
```bash
# 1) انسخ المتغيرات
cp .env.example .env

# 2) شغّل قاعدة البيانات
docker compose up -d

# 3) ثبّت الاعتماديات
npm i

# 4) أنشئ الجداول
npx prisma migrate dev --name init

# 5) شغّل التطوير
npm run dev
```

افتح: http://localhost:3000

- لوحة التحكم: `/dashboard`
- إنشاء سيرة: `/new`
- عرض عام: `/r/{slug}`
- تنزيل PDF: `/r/{slug}/pdf`

> **ملاحظة**: لم نفعّل تسجيل الدخول لتبسيط الـ MVP. أضف NextAuth لاحقًا عند الحاجة.

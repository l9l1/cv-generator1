"use client";

import { useForm, useFieldArray } from "react-hook-form";
import { useState, useTransition } from "react";
import { ResumePayload } from "@/src/types";
import { useRouter } from "next/navigation";

const defaultData: ResumePayload = {
  title: "سيرتي الذاتية",
  fullName: "فلان الفلاني",
  role: "مسؤول دعم فني",
  summary: "ملخص قصير عن خبراتك ومهاراتك.",
  phone: "",
  email: "",
  location: "الرياض، السعودية",
  skills: ["الدعم الفني", "حل المشاكل", "Windows", "Networking"],
  sections: [
    {
      kind: "experience",
      heading: "الخبرات",
      order: 0,
      items: [{
        title: "فني دعم - شركة ABC",
        subtitle: "دوام كامل",
        start: "2022",
        end: "حتى الآن",
        bullets: ["حل 50+ تذكرة شهريًا", "تحسين رضا العملاء 20%"]
      }]
    },
    {
      kind: "education",
      heading: "التعليم",
      order: 1,
      items: [{
        title: "دبلوم دعم فني",
        subtitle: "الكلية التقنية بالرياض",
        start: "2019",
        end: "2022"
      }]
    }
  ],
  templateKey: "clean",
  slug: "cv-demo"
};

export default function ResumeForm({ initial }: { initial?: Partial<ResumePayload & { id: string }>}) {
  const router = useRouter();
  const [pending, startTransition] = useTransition();
  const { register, handleSubmit, control, watch } = useForm<ResumePayload>({
    defaultValues: initial ? (initial as any) : defaultData
  });
  const { fields: sectionFields, append, remove } = useFieldArray({ control, name: "sections" as const });

  async function onSubmit(data: ResumePayload) {
    const method = initial?.id ? "PUT" : "POST";
    const url = initial?.id ? `/api/resumes/${initial.id}` : "/api/resumes`";
    const realUrl = initial?.id ? `/api/resumes/${initial.id}` : "/api/resumes";
    startTransition(async () => {
      const res = await fetch(realUrl, { method, headers: { "Content-Type": "application/json" }, body: JSON.stringify(data) });
      if (!res.ok) { alert("حدث خطأ"); return; }
      const json = await res.json();
      router.push(`/edit/${json.id}`);
      router.refresh();
    });
  }

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
      <div className="grid md:grid-cols-2 gap-4">
        <div className="card space-y-2">
          <label className="label">عنوان السيرة</label>
          <input className="input" {...register("title")} />
          <label className="label">الاسم الكامل</label>
          <input className="input" {...register("fullName")} />
          <label className="label">المسمى الوظيفي</label>
          <input className="input" {...register("role")} />
          <label className="label">الملخص</label>
          <textarea className="input" rows={4} {...register("summary")} />
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="label">البريد</label>
              <input className="input" {...register("email")} />
            </div>
            <div>
              <label className="label">الهاتف</label>
              <input className="input" {...register("phone")} />
            </div>
          </div>
          <label className="label">الموقع</label>
          <input className="input" {...register("location")} />
          <label className="label">المهارات (افصل بفاصلة)</label>
          <input className="input" {...register("skills", { setValueAs: (v) => typeof v === "string" ? v.split(",").map((s: string) => s.trim()).filter(Boolean) : v })} />
          <label className="label">الرابط (slug)</label>
          <input className="input" {...register("slug")} />
        </div>

        <div className="space-y-4">
          {sectionFields.map((sec, idx) => (
            <div key={sec.id} className="card space-y-2">
              <div className="flex items-center justify-between">
                <h3 className="font-semibold">قسم #{idx + 1}</h3>
                <button type="button" className="btn" onClick={() => remove(idx)}>حذف</button>
              </div>
              <label className="label">العنوان</label>
              <input className="input" {...register(`sections.${idx}.heading` as const)} />
              <label className="label">النوع</label>
              <input className="input" placeholder="experience / education / projects" {...register(`sections.${idx}.kind` as const)} />
              <label className="label">الترتيب</label>
              <input className="input" type="number" {...register(`sections.${idx}.order` as const, { valueAsNumber: true })} />
              <ItemsEditor namePrefix={`sections.${idx}.items`} control={control as any} register={register as any} />
            </div>
          ))}
          <button type="button" className="btn" onClick={() => append({ kind: "custom", heading: "قسم جديد", order: sectionFields.length, items: [] as any })}>
            + إضافة قسم
          </button>
        </div>
      </div>

      <div className="flex gap-3">
        <button className="btn" type="submit" disabled={pending}>{initial?.id ? "حفظ التعديلات" : "إنشاء السيرة"}</button>
      </div>
    </form>
  );
}

function ItemsEditor({ namePrefix, control, register }: any) {
  const { fields, append, remove } = useFieldArray({ control, name: namePrefix });
  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <h4 className="font-medium">العناصر</h4>
        <button type="button" className="btn" onClick={() => append({ title: "المسمى", subtitle: "", start: "", end: "", bullets: [] })}>+ عنصر</button>
      </div>
      {fields.map((f: any, i: number) => (
        <div key={f.id} className="rounded-lg border border-white/10 p-3 space-y-2">
          <label className="label">العنوان</label>
          <input className="input" {...register(`${namePrefix}.${i}.title`)} />
          <label className="label">وصف قصير</label>
          <input className="input" {...register(`${namePrefix}.${i}.subtitle`)} />
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="label">من</label>
              <input className="input" {...register(`${namePrefix}.${i}.start`)} />
            </div>
            <div>
              <label className="label">إلى</label>
              <input className="input" {...register(`${namePrefix}.${i}.end`)} />
            </div>
          </div>
          <label className="label">نقاط (افصل بفاصلة)</label>
          <input className="input" {...register(`${namePrefix}.${i}.bullets`, { setValueAs: (v: any) => typeof v === "string" ? v.split(",").map((s: string) => s.trim()).filter(Boolean) : v })} />
          <div className="flex justify-end">
            <button type="button" className="btn" onClick={() => remove(i)}>حذف العنصر</button>
          </div>
        </div>
      ))}
    </div>
  );
}

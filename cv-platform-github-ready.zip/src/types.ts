export type ResumeItem = {
  title: string;
  subtitle?: string;
  start?: string;
  end?: string;
  bullets?: string[];
};
export type ResumeSection = {
  kind: string;
  heading: string;
  items: ResumeItem[];
  order: number;
};
export type ResumePayload = {
  title: string;
  fullName: string;
  role?: string;
  summary?: string;
  phone?: string;
  email?: string;
  location?: string;
  skills: string[];
  sections: ResumeSection[];
  templateKey?: string;
  slug?: string;
};

import Link from "next/link";
import { prisma } from "@/src/lib/prisma";

export const dynamic = "force-dynamic";

export default async function Dashboard() {
  const resumes = await prisma.resume.findMany({ orderBy: { updatedAt: "desc" }});
  return (
    <main className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">لوحة التحكم</h1>
        <Link className="btn" href="/new">سيرة جديدة</Link>
      </div>
      <div className="grid md:grid-cols-2 gap-4">
        {resumes.map(r => (
          <div key={r.id} className="card">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-semibold">{r.title}</h3>
                <p className="text-white/60 text-sm">{r.fullName} • آخر تحديث: {new Date(r.updatedAt).toLocaleDateString("ar-SA")}</p>
              </div>
              <div className="flex gap-2">
                <Link className="btn" href={`/edit/${r.id}`}>تعديل</Link>
                <Link className="btn" href={`/r/${r.slug}`}>عرض</Link>
              </div>
            </div>
          </div>
        ))}
        {resumes.length === 0 && (
          <p className="text-white/70">لا توجد سير بعد — ابدأ بإنشاء أول سيرة.</p>
        )}
      </div>
    </main>
  );
}

import { prisma } from "@/src/lib/prisma";
import ResumeForm from "@/src/components/ResumeForm";

export default async function EditResume({ params }: { params: { id: string }}) {
  const resume = await prisma.resume.findUnique({ where: { id: params.id }, include: { sections: true }});
  if (!resume) return <p className="text-white/70">غير موجود</p>;
  return (
    <main className="space-y-6">
      <h1 className="text-2xl font-bold">تعديل: {resume.title}</h1>
      <ResumeForm initial={{
        id: resume.id,
        title: resume.title,
        fullName: resume.fullName,
        role: resume.role ?? undefined,
        summary: resume.summary ?? undefined,
        phone: resume.phone ?? undefined,
        email: resume.email ?? undefined,
        location: resume.location ?? undefined,
        skills: resume.skills,
        sections: resume.sections.map(s => ({ kind: s.kind, heading: s.heading, items: s.items as any, order: s.order })),
        templateKey: resume.templateKey,
        slug: resume.slug
      }} />
    </main>
  );
}

import ResumeForm from "@/src/components/ResumeForm";

export default function NewResume() {
  return (
    <main className="space-y-6">
      <h1 className="text-2xl font-bold">إنشاء سيرة ذاتية</h1>
      <ResumeForm />
    </main>
  );
}

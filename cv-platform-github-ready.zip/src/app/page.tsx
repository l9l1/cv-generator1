import Link from "next/link";

export default function Home() {
  return (
    <main className="space-y-8">
      <header className="text-center space-y-4">
        <h1 className="text-3xl md:text-5xl font-bold">منصّة سِيَر ذاتية احترافية</h1>
        <p className="text-white/70">أنشئ، عدّل، وصدّر سيرتك الذاتية PDF خلال دقائق.</p>
        <div className="flex items-center justify-center gap-3">
          <Link className="btn" href="/dashboard">ابدأ الآن</Link>
          <a className="link" href="https://github.com/" target="_blank" rel="noreferrer">الكود المصدري</a>
        </div>
      </header>
      <section className="grid md:grid-cols-2 gap-6">
        <div className="card space-y-3">
          <h2 className="text-xl font-semibold">محرّر مرن</h2>
          <p className="text-white/70">أقسام الخبرة، التعليم، المشاريع، والمهارات بواجهة بسيطة.</p>
        </div>
        <div className="card space-y-3">
          <h2 className="text-xl font-semibold">قوالب جاهزة</h2>
          <p className="text-white/70">اختر قالبًا نظيفًا عربي/إنجليزي مع دعم RTL.</p>
        </div>
      </section>
    </main>
  );
}

import "./globals.css";
import { ReactNode } from "react";
export const metadata = {
  title: "CV Platform",
  description: "Build a professional resume in minutes"
};
export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="ar" dir="rtl">
      <body>
        <div className="containerish py-8">{children}</div>
      </body>
    </html>
  );
}

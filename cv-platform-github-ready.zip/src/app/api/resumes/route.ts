import { prisma } from "@/src/lib/prisma";
import { NextResponse } from "next/server";

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const slug = (body.slug || body.fullName).toString().trim().toLowerCase().replace(/\s+/g, "-").slice(0, 64);
    const resume = await prisma.resume.create({
      data: {
        title: body.title,
        fullName: body.fullName,
        role: body.role,
        summary: body.summary,
        phone: body.phone,
        email: body.email,
        location: body.location,
        skills: body.skills || [],
        templateKey: body.templateKey || "clean",
        slug,
        sections: {
          create: (body.sections || []).map((s: any, idx: number) => ({
            kind: s.kind,
            heading: s.heading,
            items: s.items || [],
            order: s.order ?? idx
          }))
        }
      }
    });
    return NextResponse.json(resume);
  } catch (e: any) {
    return new NextResponse(e.message, { status: 400 });
  }
}

export async function GET() {
  const all = await prisma.resume.findMany({ include: { sections: true }, orderBy: { createdAt: "desc" } });
  return NextResponse.json(all);
}

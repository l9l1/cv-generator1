import { prisma } from "@/src/lib/prisma";
import { NextResponse } from "next/server";

export async function GET(_: Request, { params }: { params: { id: string }}) {
  const resume = await prisma.resume.findUnique({ where: { id: params.id }, include: { sections: true } });
  if (!resume) return new NextResponse("Not found", { status: 404 });
  return NextResponse.json(resume);
}

export async function PUT(req: Request, { params }: { params: { id: string }}) {
  const body = await req.json();
  // Update resume basic fields
  await prisma.resume.update({
    where: { id: params.id },
    data: {
      title: body.title,
      fullName: body.fullName,
      role: body.role,
      summary: body.summary,
      phone: body.phone,
      email: body.email,
      location: body.location,
      skills: body.skills || [],
      templateKey: body.templateKey || "clean",
      slug: body.slug
    }
  });
  // Replace sections (simpler for MVP)
  await prisma.section.deleteMany({ where: { resumeId: params.id } });
  if (body.sections?.length) {
    await prisma.section.createMany({
      data: body.sections.map((s: any, idx: number) => ({
        resumeId: params.id,
        kind: s.kind,
        heading: s.heading,
        items: s.items || [],
        order: s.order ?? idx
      }))
    });
  }
  const updated = await prisma.resume.findUnique({ where: { id: params.id }, include: { sections: true } });
  return NextResponse.json(updated);
}

export async function DELETE(_: Request, { params }: { params: { id: string }}) {
  await prisma.resume.delete({ where: { id: params.id } });
  return new NextResponse(null, { status: 204 });
}

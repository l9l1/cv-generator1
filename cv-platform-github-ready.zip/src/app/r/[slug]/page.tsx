import { prisma } from "@/src/lib/prisma";
import Link from "next/link";

export default async function PublicResume({ params }: { params: { slug: string }}) {
  const resume = await prisma.resume.findUnique({ where: { slug: params.slug }, include: { sections: { orderBy: { order: "asc" }}}});
  if (!resume) return <p className="text-white/70">غير موجود</p>;
  return (
    <main className="space-y-6 print:space-y-3">
      <header className="space-y-1 print:text-black">
        <h1 className="text-3xl font-bold">{resume.fullName}</h1>
        {resume.role && <p className="text-white/70">{resume.role}</p>}
        <p className="text-white/60 text-sm">{[resume.email, resume.phone, resume.location].filter(Boolean).join(" • ")}</p>
      </header>
      {resume.summary && (
        <section className="space-y-2">
          <h2 className="text-xl font-semibold">الملخص</h2>
          <p className="text-white/80">{resume.summary}</p>
        </section>
      )}
      {resume.sections.map(sec => (
        <section key={sec.id} className="space-y-2">
          <h3 className="text-lg font-semibold">{sec.heading}</h3>
          <ul className="space-y-2">
            {(sec.items as any[]).map((it, i) => (
              <li key={i}>
                <div className="flex items-center justify-between">
                  <span className="font-medium">{it.title}</span>
                  <span className="text-sm text-white/60">{[it.start, it.end].filter(Boolean).join(" - ")}</span>
                </div>
                {it.subtitle && <p className="text-white/70 text-sm">{it.subtitle}</p>}
                {it.bullets && (
                  <ul className="list-disc pr-5 text-sm text-white/80">
                    {it.bullets.map((b: string, j: number) => <li key={j}>{b}</li>)}
                  </ul>
                )}
              </li>
            ))}
          </ul>
        </section>
      ))}
      <div className="flex gap-2 no-print">
        <Link href={`/r/${resume.slug}/pdf`} className="btn">تحميل PDF</Link>
      </div>
    </main>
  );
}

import { prisma } from "@/src/lib/prisma";
import { NextResponse } from "next/server";
import { Document, Page, Text, View, StyleSheet, Font, pdf } from "@react-pdf/renderer";

export async function GET(_: Request, { params }: { params: { slug: string }}) {
  const resume = await prisma.resume.findUnique({ where: { slug: params.slug }, include: { sections: { orderBy: { order: "asc" }}}});
  if (!resume) return new NextResponse("Not found", { status: 404 });

  const styles = StyleSheet.create({
    page: { padding: 32, fontSize: 11, fontFamily: "Helvetica" },
    h1: { fontSize: 20, marginBottom: 4 },
    muted: { color: "#666" },
    section: { marginTop: 12 },
    h2: { fontSize: 13, marginBottom: 4 }
  });

  const Doc = () => (
    <Document>
      <Page size="A4" style={styles.page}>
        <Text style={styles.h1}>{resume.fullName}</Text>
        {resume.role && <Text style={styles.muted}>{resume.role}</Text>}
        <Text style={styles.muted}>{[resume.email, resume.phone, resume.location].filter(Boolean).join(" • ")}</Text>
        {resume.summary && (
          <View style={styles.section}>
            <Text style={styles.h2}>الملخص</Text>
            <Text>{resume.summary}</Text>
          </View>
        )}
        {resume.sections.map((sec) => (
          <View key={sec.id} style={styles.section}>
            <Text style={styles.h2}>{sec.heading}</Text>
            {((sec.items as any[]) || []).map((it, i) => (
              <View key={i}>
                <Text>{it.title} {it.subtitle ? `• ${it.subtitle}` : ""}</Text>
                <Text style={styles.muted}>{[it.start, it.end].filter(Boolean).join(" - ")}</Text>
                {it.bullets && it.bullets.map((b: string, j: number) => <Text key={j}>• {b}</Text>)}
              </View>
            ))}
          </View>
        ))}
      </Page>
    </Document>
  );

  const blob = await pdf(<Doc />).toBuffer();
  return new NextResponse(blob, {
    headers: {
      "Content-Type": "application/pdf",
      "Content-Disposition": `attachment; filename="${resume.slug}.pdf"`
    }
  });
}
